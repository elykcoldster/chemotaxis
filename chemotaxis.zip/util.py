# Utility functions, types, and constants

# Strings
abstract_class_except_msg = "Concrete class must implement abstract method"

# Functions
class Error(Exception):
    # Simple custom Exception class for use throughout our program
    pass
