Paper with the original model that we are extending: [A Model of Drosophila Larva Chemotaxis](http://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1004606)  
Paper with the extensions (detailed concentration detection mechanisms): [Dynamical feature extraction at the sensory periphery guides chemotaxis](https://elifesciences.org/content/4/e06694)  
