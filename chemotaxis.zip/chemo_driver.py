import chemodynamics as cd

print(cd.arena_size)
print(cd.p_run_termination())